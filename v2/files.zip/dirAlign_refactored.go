package alignmentdir

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/fatih/color"
	"github.com/gmaffy/genome-whisperer/alignment"
	"github.com/gmaffy/genome-whisperer/utils"
)

// ============================================================
// Public entry point
// ============================================================

// RunAlignReadsDir discovers all samples under dataDir, inspects their current
// alignment state, then concurrently executes whatever pipeline steps are still
// needed (align from scratch → markdup → BQSR → BAM→CRAM conversion → cleanup).
//
// Concurrency: one goroutine per sample, capped by a semaphore sized to threads.
func RunAlignReadsDir(
	dataDir, species, refVer, refFasta, genomesDir string,
	verbose bool,
	gatkLogLevel, aligner string,
	quick, skipVer, bqsr, bootstrap bool,
	knownSites []string,
	threads int,
) {
	// ------------------------------------------------------------------ //
	// 1. Validate top-level inputs
	// ------------------------------------------------------------------ //
	if err := validateDirInputs(dataDir, species, refVer, aligner, bqsr, bootstrap, knownSites); err != nil {
		color.Red("Input validation failed: %v\n", err)
		return
	}

	resolvedFasta, err := resolveRefFasta(refFasta, genomesDir, species, refVer)
	if err != nil {
		color.Red("Cannot resolve reference FASTA: %v\n", err)
		return
	}
	if err := validateFastaAndDict(resolvedFasta); err != nil {
		color.Red("%v\n", err)
		return
	}

	// ------------------------------------------------------------------ //
	// 2. Prepare reference index once (not per-sample)
	// ------------------------------------------------------------------ //
	color.Cyan("Preparing reference index for %s …\n", aligner)
	if err := utils.PrepareFasta(resolvedFasta, aligner, verbose); err != nil {
		color.Red("Failed to prepare reference FASTA: %v\n", err)
		return
	}

	// ------------------------------------------------------------------ //
	// 3. Scan alignment state for all samples
	// ------------------------------------------------------------------ //
	sampleStates, err := ScanAlignments(dataDir, species, refVer, genomesDir, resolvedFasta, verbose, quick)
	if err != nil {
		color.Red("Alignment scan failed: %v\n", err)
		return
	}
	if len(sampleStates) == 0 {
		color.Yellow("No samples found — nothing to do.\n")
		return
	}

	// ------------------------------------------------------------------ //
	// 4. Determine per-sample actions
	// ------------------------------------------------------------------ //
	type workItem struct {
		state  SampleBamState
		action Action
	}

	var items []workItem
	for _, s := range sampleStates {
		a := GetSampleActions(s)
		if a.Perfect {
			color.Green("[%s] Already complete — skipping.\n", s.Sample)
			continue
		}
		items = append(items, workItem{state: s, action: a})
	}

	if len(items) == 0 {
		color.Green("All samples are already complete. Nothing to do.\n")
		return
	}

	// ------------------------------------------------------------------ //
	// 5. Process samples concurrently (semaphore = threads)
	// ------------------------------------------------------------------ //
	// We use one goroutine per sample and a semaphore to cap concurrency so
	// we don't saturate I/O or CPU when there are many samples.
	sem := make(chan struct{}, max(1, threads))
	var wg sync.WaitGroup
	var mu sync.Mutex
	var failedSamples []string

	for _, item := range items {
		wg.Add(1)
		go func(w workItem) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			cfg := sampleConfig{
				resolvedFasta: resolvedFasta,
				aligner:       aligner,
				gatkLogLevel:  gatkLogLevel,
				verbose:       verbose,
				bqsr:          bqsr,
				bootstrap:     bootstrap,
				knownSites:    knownSites,
				threads:       threads,
				dataDir:       dataDir,
				species:       species,
				refVer:        refVer,
			}

			if err := processSample(w.state, w.action, cfg); err != nil {
				color.Red("[%s] Failed: %v\n", w.state.Sample, err)
				mu.Lock()
				failedSamples = append(failedSamples, w.state.Sample)
				mu.Unlock()
			} else {
				color.Green("[%s] ✅ Done\n", w.state.Sample)
			}
		}(item)
	}

	wg.Wait()

	// ------------------------------------------------------------------ //
	// 6. Summary
	// ------------------------------------------------------------------ //
	if len(failedSamples) > 0 {
		color.Red("\n%d sample(s) failed: %s\n", len(failedSamples), strings.Join(failedSamples, ", "))
	} else {
		color.Green("\nAll %d sample(s) processed successfully.\n", len(items))
	}
}

// ============================================================
// Per-sample processing
// ============================================================

// sampleConfig bundles all run-level settings so we avoid long argument lists.
type sampleConfig struct {
	resolvedFasta string
	aligner       string
	gatkLogLevel  string
	verbose       bool
	bqsr          bool
	bootstrap     bool
	knownSites    []string
	threads       int
	dataDir       string
	species       string
	refVer        string
}

// processSample executes every Step recorded in an Action for a single sample.
// It understands two broad modes:
//   - "scratch"  → full alignment from raw reads (delegates to RunAlignReads)
//   - everything else → individual post-processing steps on existing BAMs/CRAMs
func processSample(s SampleBamState, a Action, cfg sampleConfig) error {
	color.Cyan("[%s] Processing — %d step(s)\n", s.Sample, len(a.Steps))

	for _, step := range a.Steps {
		color.Blue("[%s] %s  ← %s\n", s.Sample, step.Program, strings.Join(step.Inputs, ", "))

		var err error
		switch step.Program {

		// ---- Full realignment from clean reads ---- //
		case "scratch":
			err = alignFromScratch(s.Sample, cfg)

		// ---- Post-processing steps ---- //
		case "markdup":
			err = alignment.MarkDuplicates(cfg.resolvedFasta, step.Inputs[0], cfg.verbose, cfg.aligner, cfg.gatkLogLevel)
			if err == nil {
				// Index the newly created RGMD bam
				rgmdBam := rgmdBamPath(step.Inputs[0])
				err = alignment.BamIndex(rgmdBam, cfg.verbose)
			}

		case "bqsr":
			if cfg.aligner == "pbmm2" {
				color.Yellow("[%s] Skipping BQSR — not supported for pbmm2\n", s.Sample)
				continue
			}
			inputBam := step.Inputs[0]
			bqsrBam, bqsrErr := alignment.BaseQualityScoreRecalibration(
				cfg.resolvedFasta, inputBam,
				cfg.knownSites, cfg.bootstrap,
				cfg.verbose, cfg.gatkLogLevel,
			)
			if bqsrErr != nil {
				err = bqsrErr
			} else {
				err = alignment.BamIndex(bqsrBam, cfg.verbose)
			}

		case "bam_to_cram":
			cramPath := strings.TrimSuffix(step.Inputs[0], ".bam") + ".cram"
			err = alignment.BamToCram(step.Inputs[0], cramPath, cfg.resolvedFasta, cfg.verbose)
			if err == nil {
				err = alignment.BamIndex(cramPath, cfg.verbose)
			}

		case "indexBam":
			err = alignment.BamIndex(step.Inputs[0], cfg.verbose)

		case "rm":
			if rmErr := os.Remove(step.Inputs[0]); rmErr != nil && !os.IsNotExist(rmErr) {
				color.Yellow("[%s] Could not remove %s: %v\n", s.Sample, step.Inputs[0], rmErr)
				// Non-fatal: log and continue
			}

		default:
			color.Yellow("[%s] Unknown step %q — skipping\n", s.Sample, step.Program)
		}

		if err != nil {
			return fmt.Errorf("step %q on %q: %w", step.Program, step.Inputs[0], err)
		}
	}

	return nil
}

// alignFromScratch locates the clean_reads directory for a sample and runs the
// full alignment pipeline (align → markdup → optional BQSR → optional CRAM).
func alignFromScratch(sampleName string, cfg sampleConfig) error {
	// ---- Locate clean reads ---- //
	pattern := filepath.Join(cfg.dataDir, cfg.species, "*", sampleName, "clean_reads")
	matches, err := filepath.Glob(pattern)
	if err != nil || len(matches) == 0 {
		return fmt.Errorf("no clean_reads directory found for sample %q (pattern: %s)", sampleName, pattern)
	}
	cleanReadsDir := matches[0]

	fwdReads, revReads, err := GetReadsPE(cleanReadsDir)
	if err != nil {
		return fmt.Errorf("discovering paired reads: %w", err)
	}
	if len(fwdReads) == 0 || len(revReads) == 0 {
		return fmt.Errorf("no paired reads found in %s", cleanReadsDir)
	}
	if len(fwdReads) != len(revReads) {
		return fmt.Errorf("read count mismatch: %d forward vs %d reverse in %s", len(fwdReads), len(revReads), cleanReadsDir)
	}

	// ---- Derive output directory: …/<species>/<group>/<sample>/reference_genomes/<refVer>/bams ---- //
	sampleDir := filepath.Dir(cleanReadsDir)
	outDir := filepath.Join(sampleDir, "reference_genomes", cfg.refVer, "bams")
	if err := os.MkdirAll(outDir, 0755); err != nil {
		return fmt.Errorf("creating output directory %s: %w", outDir, err)
	}

	// ---- Run alignment for each read-pair (usually one, but supports split lanes) ---- //
	for i := range fwdReads {
		libName := fmt.Sprintf("%s_lib%d", sampleName, i+1)
		logFile := filepath.Join(outDir, fmt.Sprintf("alignment_lib%d.log", i+1))

		outputFmt := "cram" // dir-mode always aims for CRAM as the final product
		finalFile, alignErr := alignment.RunAlignReads(
			cfg.resolvedFasta,
			fwdReads[i], revReads[i],
			"", // sePath not used for paired-end
			sampleName, libName,
			outDir,
			cfg.threads,
			cfg.aligner,
			cfg.knownSites,
			cfg.bqsr, cfg.bootstrap,
			logFile,
			"HIFI", // preset only relevant for pbmm2
			cfg.gatkLogLevel,
			cfg.verbose,
			outputFmt,
		)
		if alignErr != nil {
			return fmt.Errorf("lane %d alignment: %w", i+1, alignErr)
		}
		color.Green("[%s] Lane %d aligned → %s\n", sampleName, i+1, finalFile)
	}

	return nil
}

// ============================================================
// Helper utilities
// ============================================================

// rgmdBamPath derives the RGMD bam path produced by MarkDuplicates from a
// sorted.bam input path (mirrors the logic in alignment.MarkDuplicates).
func rgmdBamPath(sortedBam string) string {
	base := strings.TrimSuffix(strings.TrimSuffix(sortedBam, ".bam"), ".cram")
	return base + ".RGMD.bam"
}

// validateDirInputs performs upfront validation of required parameters before
// any filesystem work begins.
func validateDirInputs(dataDir, species, refVer, aligner string, bqsr, bootstrap bool, knownSites []string) error {
	info, err := os.Stat(dataDir)
	if err != nil {
		return fmt.Errorf("accessing data directory %q: %w", dataDir, err)
	}
	if !info.IsDir() {
		return fmt.Errorf("%q is not a directory", dataDir)
	}
	if species == "" {
		return fmt.Errorf("species name is required")
	}
	if refVer == "" {
		return fmt.Errorf("reference version is required")
	}
	if bqsr {
		if aligner == "pbmm2" {
			return fmt.Errorf("BQSR is not supported with pbmm2; disable BQSR or switch aligner")
		}
		if len(knownSites) == 0 && !bootstrap {
			return fmt.Errorf("BQSR requires either --known-sites or --bootstrap")
		}
		if len(knownSites) > 0 && bootstrap {
			return fmt.Errorf("specify either --known-sites or --bootstrap, not both")
		}
		for _, ks := range knownSites {
			if _, err := os.Stat(ks); err != nil {
				return fmt.Errorf("known-sites file not accessible %q: %w", ks, err)
			}
		}
	}
	return nil
}

// validateFastaAndDict checks that both the FASTA and its .dict companion exist.
func validateFastaAndDict(fastaPath string) error {
	info, err := os.Stat(fastaPath)
	if err != nil {
		return fmt.Errorf("reference FASTA %q not accessible: %w", fastaPath, err)
	}
	if !info.Mode().IsRegular() {
		return fmt.Errorf("reference FASTA %q is not a regular file", fastaPath)
	}
	dictPath := strings.TrimSuffix(fastaPath, filepath.Ext(fastaPath)) + ".dict"
	if _, err := os.Stat(dictPath); err != nil {
		return fmt.Errorf("reference .dict file %q not found: %w", dictPath, err)
	}
	return nil
}

// max returns the larger of a and b (stdlib max requires Go 1.21+).
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
