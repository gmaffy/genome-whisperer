package alignment

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/gmaffy/genome-whisperer/utils"
)

// BamToCram converts a BAM file to CRAM format using samtools.
func BamToCram(bamPath, cramPath, refFasta string, verbose bool) error {
	cmd := fmt.Sprintf(`samtools view -T %s -C -o %s %s`, refFasta, cramPath, bamPath)
	return run(cmd, verbose)
}

// BwaMem2Align aligns paired-end reads with bwa-mem2 and produces a sorted BAM.
func BwaMem2Align(forwardPath, reversePath, referencePath, sampleName, libName string, threads int, sortedBam string, verbose bool) error {
	rg := readGroup(sampleName, libName)
	cmd := fmt.Sprintf(
		`bwa-mem2 mem -t %d -M -Y -R '%s' %s %s %s | samtools sort -o %s`,
		threads, rg, referencePath, forwardPath, reversePath, sortedBam,
	)
	printCmd(cmd)
	return run(cmd, verbose)
}

// BwaMemAlign aligns paired-end reads with bwa mem and produces a sorted BAM.
func BwaMemAlign(forwardPath, reversePath, referencePath, sampleName, libName string, threads int, sortedBam string, verbose bool) error {
	rg := readGroup(sampleName, libName)
	cmd := fmt.Sprintf(
		`bwa mem -t %d -M -Y -R '%s' %s %s %s | samtools sort -o %s`,
		threads, rg, referencePath, forwardPath, reversePath, sortedBam,
	)
	printCmd(cmd)
	return run(cmd, verbose)
}

// Bowtie2Align aligns paired-end reads with bowtie2 and produces a sorted BAM.
func Bowtie2Align(forwardPath, reversePath, referencePath, sortedBam, sampleName, libName string, threads int, verbose bool) error {
	cmd := fmt.Sprintf(
		`bowtie2 -I 0 -X 1000 -x %s -1 %s -2 %s --end-to-end --sensitive --threads %d`+
			` --rg-id %s.1 --rg PL:BGISEQ --rg SM:%s --rg LB:%s | samtools sort -o %s`,
		referencePath, forwardPath, reversePath, threads,
		sampleName, sampleName, libName, sortedBam,
	)
	printCmd(cmd)
	return run(cmd, verbose)
}

// Pbmm2Align aligns single-end long reads with pbmm2 and produces a sorted BAM.
// It automatically indexes the reference if the .mmi index is absent.
func Pbmm2Align(sePath, referencePath, sortedBam, preset string, threads int, verbose bool) error {
	mmiPath := referencePath + ".mmi"
	if _, err := os.Stat(mmiPath); err != nil {
		fmt.Println("Reference index not found — indexing reference …")
		indexCmd := fmt.Sprintf(`pbmm2 index %s %s`, referencePath, mmiPath)
		printCmd(indexCmd)
		if err := run(indexCmd, verbose); err != nil {
			return fmt.Errorf("pbmm2 index: %w", err)
		}
	}
	cmd := fmt.Sprintf(`pbmm2 align --sort -j %d --preset %s %s %s %s`, threads, preset, mmiPath, sePath, sortedBam)
	printCmd(cmd)
	return run(cmd, verbose)
}

// AddReadGroups replaces / adds read-group tags on a BAM using GATK.
func AddReadGroups(sortedBam, rgBam, sampleName, libName string, verbose bool) error {
	cmd := fmt.Sprintf(
		`gatk AddOrReplaceReadGroups -I %s -O %s -ID %s.1 -LB %s -PL PACBIO -PU BKD -SM %s`,
		sortedBam, rgBam, sampleName, libName, sampleName,
	)
	printCmd(cmd)
	return run(cmd, verbose)
}

// BamIndex builds a .bai / .crai index with samtools.
func BamIndex(bam string, verbose bool) error {
	cmd := fmt.Sprintf(`samtools index %s`, bam)
	printCmd(cmd)
	return run(cmd, verbose)
}

// MarkDuplicates marks duplicate reads.
// For short-read aligners it delegates to GATK MarkDuplicates; for pbmm2 it uses pbmarkdup.
func MarkDuplicates(referencePath, sortedBam string, verbose bool, aligner, gatkLogLevel string) error {
	base := strings.TrimSuffix(strings.TrimSuffix(sortedBam, ".bam"), ".cram")
	rgmdBam := base + ".RGMD.bam"
	metrics := base + ".RGMD.metrics.txt"

	var cmd string
	switch aligner {
	case "pbmm2":
		cmd = fmt.Sprintf(`pbmarkdup %s %s`, sortedBam, rgmdBam)
	default: // bwa-mem, bwa-mem2, bowtie2
		cmd = fmt.Sprintf(
			`gatk --java-options "-Xmx8G" MarkDuplicates -R %s -I %s -O %s -M %s --VERBOSITY %s`,
			referencePath, sortedBam, rgmdBam, metrics, gatkLogLevel,
		)
	}
	printCmd(cmd)
	return run(cmd, verbose)
}

// BaseQualityScoreRecalibration runs GATK BQSR (BaseRecalibrator + ApplyBQSR).
// knownSites must be non-empty unless bootstrap is true, in which case the
// recalibration table is built from the input BAM itself (first-pass bootstrap).
func BaseQualityScoreRecalibration(referencePath, inputBam string, knownSites []string, bootstrap, verbose bool, gatkLogLevel string) (string, error) {
	base := strings.TrimSuffix(strings.TrimSuffix(inputBam, ".bam"), ".cram")
	recalTable := base + ".recal.table"
	bqsrBam := base + ".BQSR.bam"

	// ---- BaseRecalibrator ---- //
	var ksFlags string
	for _, ks := range knownSites {
		ksFlags += fmt.Sprintf(" --known-sites %s", ks)
	}

	recalCmd := fmt.Sprintf(
		`gatk --java-options "-Xmx8G" BaseRecalibrator -R %s -I %s%s -O %s --verbosity %s`,
		referencePath, inputBam, ksFlags, recalTable, gatkLogLevel,
	)

	if bootstrap {
		// Bootstrap: first pass without known sites to produce an initial table,
		// then a second pass after applying those corrections — single iteration here.
		recalCmd = fmt.Sprintf(
			`gatk --java-options "-Xmx8G" BaseRecalibrator -R %s -I %s -O %s --verbosity %s`,
			referencePath, inputBam, recalTable, gatkLogLevel,
		)
	}

	printCmd(recalCmd)
	if err := run(recalCmd, verbose); err != nil {
		return "", fmt.Errorf("BaseRecalibrator: %w", err)
	}

	// ---- ApplyBQSR ---- //
	applyCmd := fmt.Sprintf(
		`gatk --java-options "-Xmx8G" ApplyBQSR -R %s -I %s --bqsr-recal-file %s -O %s --verbosity %s`,
		referencePath, inputBam, recalTable, bqsrBam, gatkLogLevel,
	)
	printCmd(applyCmd)
	if err := run(applyCmd, verbose); err != nil {
		return "", fmt.Errorf("ApplyBQSR: %w", err)
	}

	return bqsrBam, nil
}

// RunAlignReads is the single-sample alignment entry point.
// It handles paired-end short reads (bwa-mem, bwa-mem2, bowtie2) and long reads (pbmm2),
// optional BQSR, and converts the final BAM to CRAM when outputFmt == "cram".
//
// Returned string is the path to the final output file (BAM or CRAM).
func RunAlignReads(
	referencePath, forwardPath, reversePath, sePath,
	sampleName, libName, outDir string,
	threads int,
	aligner string,
	knownSites []string,
	bqsr, bootstrap bool,
	logFilePath, preset, gatkLogLevel string,
	verbose bool,
	outputFmt string,
) (string, error) {

	// ---- Derive output paths ---- //
	sortedBam := filepath.Join(outDir, sampleName+".sorted.bam")
	rgmdBam := filepath.Join(outDir, sampleName+".RGMD.bam")

	// ================================================================
	// STEP 1 — Initial alignment → sorted BAM
	// ================================================================
	fmt.Printf("\n[%s] Step 1 — Aligning reads with %s\n", sampleName, aligner)

	var alignErr error
	switch aligner {
	case "bwa-mem":
		alignErr = BwaMemAlign(forwardPath, reversePath, referencePath, sampleName, libName, threads, sortedBam, verbose)
	case "bwa-mem2":
		alignErr = BwaMem2Align(forwardPath, reversePath, referencePath, sampleName, libName, threads, sortedBam, verbose)
	case "bowtie2":
		alignErr = Bowtie2Align(forwardPath, reversePath, referencePath, sortedBam, sampleName, libName, threads, verbose)
	case "pbmm2":
		alignErr = Pbmm2Align(sePath, referencePath, sortedBam, preset, threads, verbose)
	default:
		return "", fmt.Errorf("unsupported aligner: %s", aligner)
	}
	if alignErr != nil {
		return "", fmt.Errorf("alignment failed: %w", alignErr)
	}

	// ================================================================
	// STEP 2 — Index sorted BAM
	// ================================================================
	fmt.Printf("\n[%s] Step 2 — Indexing sorted BAM\n", sampleName)
	if err := BamIndex(sortedBam, verbose); err != nil {
		return "", fmt.Errorf("indexing sorted BAM: %w", err)
	}

	// ================================================================
	// STEP 3 — Mark duplicates → rgmd BAM
	// ================================================================
	fmt.Printf("\n[%s] Step 3 — Marking duplicates\n", sampleName)
	if err := MarkDuplicates(referencePath, sortedBam, verbose, aligner, gatkLogLevel); err != nil {
		return "", fmt.Errorf("mark duplicates: %w", err)
	}

	// ================================================================
	// STEP 4 — Index rgmd BAM
	// ================================================================
	fmt.Printf("\n[%s] Step 4 — Indexing RGMD BAM\n", sampleName)
	if err := BamIndex(rgmdBam, verbose); err != nil {
		return "", fmt.Errorf("indexing RGMD BAM: %w", err)
	}

	currentBam := rgmdBam // track "latest best" BAM through the pipeline

	// ================================================================
	// STEP 5 (optional) — BQSR
	// ================================================================
	if bqsr {
		fmt.Printf("\n[%s] Step 5 — Base quality score recalibration\n", sampleName)
		bqsrBam, err := BaseQualityScoreRecalibration(referencePath, rgmdBam, knownSites, bootstrap, verbose, gatkLogLevel)
		if err != nil {
			return "", fmt.Errorf("BQSR: %w", err)
		}
		if err := BamIndex(bqsrBam, verbose); err != nil {
			return "", fmt.Errorf("indexing BQSR BAM: %w", err)
		}
		currentBam = bqsrBam
	}

	// ================================================================
	// STEP 6 — Convert to CRAM (if requested)
	// ================================================================
	finalOutput := currentBam
	if strings.ToLower(outputFmt) == "cram" {
		cramPath := strings.TrimSuffix(currentBam, ".bam") + ".cram"
		fmt.Printf("\n[%s] Step 6 — Converting to CRAM: %s\n", sampleName, cramPath)
		if err := BamToCram(currentBam, cramPath, referencePath, verbose); err != nil {
			return "", fmt.Errorf("BAM → CRAM conversion: %w", err)
		}
		if err := BamIndex(cramPath, verbose); err != nil {
			return "", fmt.Errorf("indexing CRAM: %w", err)
		}
		finalOutput = cramPath

		// Remove the intermediate BAM now that we have the CRAM
		_ = os.Remove(currentBam)
		_ = os.Remove(currentBam + ".bai")
	}

	// ================================================================
	// STEP 7 — Remove intermediate sorted BAM (always safe at this point)
	// ================================================================
	if sortedBam != currentBam {
		_ = os.Remove(sortedBam)
		_ = os.Remove(sortedBam + ".bai")
	}

	fmt.Printf("\n[%s] ✅ Alignment complete → %s\n", sampleName, finalOutput)
	return finalOutput, nil
}

// ---- internal helpers ---- //

func readGroup(sampleName, libName string) string {
	return fmt.Sprintf("@RG\\tID:%s.1\\tSM:%s\\tLB:%s\\tPL:BGISEQ", sampleName, sampleName, libName)
}

func printCmd(cmd string) {
	fmt.Printf("%s\n--------------------------------------------\n\n", cmd)
}

func run(cmd string, verbose bool) error {
	if verbose {
		return utils.RunBashCmdVerbose(cmd)
	}
	return utils.RunBashCmd(cmd)
}
